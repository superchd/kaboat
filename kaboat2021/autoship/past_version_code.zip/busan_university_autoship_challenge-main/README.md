# busan_university_autoship_challenge
Code for Busan University automatic driving ship competition!

for team mechasolution!


# LINKS
## Project1 OpenCV
https://drive.google.com/drive/folders/1iDkcBFCG4XsM0A7JCDfK8kA0qIEBei-A?usp=sharing

## Project2 YOLO
https://drive.google.com/drive/folders/1ABGKn1PrxjEbD11ZQp64DfL-0SCUDpmw?usp=sharing

## 크리스 통합문서
https://docs.google.com/document/d/13t37ClYS8YGFCrX-lMFDNfPgKYROPiuC9YF9j-whGPk/edit?usp=sharing
