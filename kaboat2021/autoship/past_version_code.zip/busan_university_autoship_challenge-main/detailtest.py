from lidar_detail import *
lidarfinalresult = lidardetail()
minindex = 0
minrange = 100
maxindex = 0
maxrange = 0
nowindex = 0

for i in lidarfinalresult:
    if(i > 0.1 and i < minrange):
        minindex = nowindex
        minrange = i
    if(i > maxrange):
        maxindex = nowindex
        maxrange = i
    nowindex += 1
print(minindex)
print(minrange)
print(maxindex)
print(maxrange)
