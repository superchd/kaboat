from imu import *
import time
while(True):
    print(imu_read())
    time.sleep(0.3)
