from shiprc import *

ship_rc_mode()
