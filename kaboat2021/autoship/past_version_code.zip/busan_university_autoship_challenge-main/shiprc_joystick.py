from socket import *
from motor import *
def ship_rc_mode():
    print("-"*15,"\nplease wait until motor starting\n","-"*15)
    motorinit()
    print("-"*15,"\nmotor started!\n","-"*15)
    speed = 15
    direction = 0
    serverSock = socket(AF_INET, SOCK_STREAM)
    serverSock.bind(('', 1972))
    serverSock.listen(1)

    connectionSock, addr = serverSock.accept()

    while(True):
        try:
            data = connectionSock.recv(1024)
            data = data.decode('utf-8')
            servodata = int(data[0:3])
            bldcdata = int(data[3:6])
            #print(data)
            #print("%d                %d"%(servodata,bldcdata))
            connectionSock.send("ok".encode('utf-8'))
            servomove(servodata)
            bldcmove(bldcdata)
        except:
            servomove(90)
            bldcmove(90)
            exit()
        
